import numpy as np
import faiss
from transformers import AutoTokenizer, AutoModelForCausalLM
import streamlit as st
import redis
from neo4j import GraphDatabase
from langchain.chains import ConversationalRetrievalChain
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.llms import Replicate
from langchain.vectorstores import FAISS
from langchain.memory import ConversationBufferMemory
from langchain.callbacks.streaming_stdout import StreamingStdOutCallbackHandler
from langchain.document_loaders import PyPDFLoader, TextLoader, Docx2txtLoader
from langchain.text_splitter import CharacterTextSplitter
import os, json
import tempfile
from dotenv import load_dotenv
import hyde
from bs4 import BeautifulSoup
from langchain_groq import ChatGroq
from sentence_transformers import SentenceTransformer, util

# Load environment variables
load_dotenv()
os.environ['GROQ_API_KEY'] = os.getenv("GROQ_API_KEY")

groq_api_key = os.getenv("GROQ_API_KEY")

# Custom HTML Loader
class HTMLLoader:
    def __init__(self, file_path):
        self.file_path = file_path

    def load(self):
        with open(self.file_path, 'r', encoding='utf-8') as file:
            soup = BeautifulSoup(file, 'html.parser')
            text = soup.get_text(separator='\n')
        return [text]

def process_reranked_docs(reranked_docs):
    return "\n\n".join([doc.page_content for doc in reranked_docs])

import json
import redis

class RedisCache:
    def __init__(self, host='localhost', port=6379, db=0):
        self.client = redis.Redis(host=host, port=port, db=db)

    def set(self, key, value):
        # Convert value to JSON string if it's a dictionary or list
        if isinstance(value, (dict, list)):
            value = json.dumps(value)
        self.client.set(key, value)

    def get(self, key):
        value = self.client.get(key)
        # Try to decode the value as JSON
        try:
            return json.loads(value)
        except (TypeError, json.JSONDecodeError):
            return value

    def add_interaction(self, interaction):
        # Example implementation
        interaction_id = interaction.get('id', 'default_id')
        self.set(interaction_id, interaction)


# Initialize Redis cache
redis_cache = RedisCache()

def initialize_session_state():
    if 'history' not in st.session_state:
        st.session_state['history'] = []

    if 'generated' not in st.session_state:
        st.session_state['generated'] = ["Hello! Ask me anything about 🤗"]

    if 'past' not in st.session_state:
        st.session_state['past'] = ["Hey! 👋"]

# Function to fetch context from Neo4j
def fetch_context_from_neo4j(user_query, driver):
    with driver.session() as session:
        result = session.run(
            "MATCH (n) WHERE n.name CONTAINS $name RETURN n LIMIT 100",
            name=user_query
        )
        record = result.single()
        if record:
            return record["n"]
        return {}

# Enhance Query with Knowledge Graph Context
def enhance_query_with_kg(query, neo4j_driver):
    context = fetch_context_from_neo4j(query, neo4j_driver)
    if context:
        return f"{query} Context: {context.get('description', '')}"
    return query

def rerank_documents(query, retrieved_docs):
    model = SentenceTransformer('all-MiniLM-L6-v2')
    document_texts = [doc.page_content for doc in retrieved_docs]
    query_embedding = model.encode(query, convert_to_tensor=True)
    doc_embeddings = model.encode(document_texts, convert_to_tensor=True)
    scores = util.cos_sim(query_embedding, doc_embeddings)[0].cpu().numpy()
    sorted_indices = np.argsort(scores)[::-1]
    return [retrieved_docs[i] for i in sorted_indices]

def conversation_chat(query, chain, history, neo4j_driver=None):
    if neo4j_driver:
        query = enhance_query_with_kg(query, neo4j_driver)
    result = chain({"question": query, "chat_history": history})
    history.append((query, result["answer"]))
    return result["answer"]

def display_chat_history(chain, neo4j_driver=None):
    reply_container = st.container()
    container = st.container()

    with container:
        with st.form(key='my_form', clear_on_submit=True):
            user_input = st.text_input("Question:", placeholder="Ask about your Documents", key='input')
            submit_button = st.form_submit_button(label='Send')

        if submit_button and user_input:
            with st.spinner('Generating response...'):
                cached_response = redis_cache.get(user_input)
                if cached_response:
                    if isinstance(cached_response, bytes):  # Check if it's a byte-like object
                        cached_response = cached_response.decode('utf-8')  # Decode it to a string
                    try:
                        # Attempt to parse the cached response as JSON
                        cached_response = json.loads(cached_response)
                    except (json.JSONDecodeError, TypeError):
                        # If parsing fails, assume it's already a usable string
                        output = cached_response
                    else:
                        # If parsed successfully, extract the relevant field
                        output = cached_response.get('answer', 'No cached response found.')
                else:
                    # If no cache, generate the response
                    output = conversation_chat(user_input, chain, st.session_state['history'], neo4j_driver)
                    
                    # Retrieve and re-rank documents
                    retrieved_docs = chain.retriever.get_relevant_documents(user_input)
                    reranked_docs = rerank_documents(user_input, retrieved_docs)
                    output = process_reranked_docs(reranked_docs)

                    # Cache the result as a JSON string
                    redis_cache.set(user_input, json.dumps({"answer": output}))

            st.session_state['past'].append(user_input)
            st.session_state['generated'].append(output)

            # Display feedback options
            feedback = st.radio(
                "How would you rate this response?",
                ("Best", "Good", "Normal", "Worst")
            )
            toxic = st.radio("Is this response toxic?", ("Yes", "No"))

            interaction = {
                "query": user_input,
                "response": output,
                "feedback": feedback,
                "toxic": toxic == "Yes" }
            redis_cache.add_interaction(interaction)

    if st.session_state['generated']:
        with reply_container:
            for i in range(len(st.session_state['generated'])):
                st.write(f"User: {st.session_state['past'][i]}")
                st.write(f"Bot: {st.session_state['generated'][i]}")



def create_conversational_chain(vector_store):
    # Initialize the LLM
    llm = ChatGroq(groq_api_key=groq_api_key, model_name="Llama3-8b-8192",max_tokens=200)

    # Create a retriever from the vector store
    retriever = vector_store.as_retriever(search_kwargs={"k": 2})
    
    memory = ConversationBufferMemory(memory_key="chat_history", return_messages=True)
    chain = ConversationalRetrievalChain.from_llm(
        llm=llm,
        chain_type='stuff',
        retriever=retriever,
        memory=memory
    )
    
    return chain, llm

def summarize_documents(llm, documents):
    # Concatenate document contents into a single string
    text_to_summarize = "\n".join([doc.page_content for doc in documents])

    # Assuming a conversational model that expects a list of messages
    messages = [{"role": "user", "content": text_to_summarize}]
    
    try:
        # Generate a summary using the LLM
        response = llm.generate(messages)
        # Extract the summary from the response
        summary = response["choices"][0]["message"]["content"]
    except Exception as e:
        print(f"An error occurred: {e}")
        summary = "Could not generate summary due to an error."
    
    return summary


def main():
    load_dotenv()
    initialize_session_state()
    st.title("Multi-Docs ChatBot using LLaMA and Redis Cache :books:")

    st.sidebar.title("Document Processing")
    uploaded_files = st.sidebar.file_uploader("Upload files", accept_multiple_files=True)

    if uploaded_files:
        text = []
        for file in uploaded_files:
            file_extension = os.path.splitext(file.name)[1]
            with tempfile.NamedTemporaryFile(delete=False) as temp_file:
                temp_file.write(file.read())
                temp_file_path = temp_file.name

            loader = None
            if file_extension == ".pdf":
                loader = PyPDFLoader(temp_file_path)
            elif file_extension in [".docx", ".doc"]:
                loader = Docx2txtLoader(temp_file_path)
            elif file_extension == ".txt":
                loader = TextLoader(temp_file_path)
            elif file_extension == ".html":
                loader = HTMLLoader(temp_file_path)

            if loader:
                text.extend(loader.load())
                os.remove(temp_file_path)

        if text:
            text_splitter = CharacterTextSplitter(separator="\n", chunk_size=1000, chunk_overlap=100, length_function=len)
            text_chunks = text_splitter.split_documents(text)

            if text_chunks:
                document_texts = [doc.page_content for doc in text_chunks]
                embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2", model_kwargs={'device': 'cpu'})
                sample_embedding = embeddings.embed_documents([document_texts[0]])
                embedding_dim = len(sample_embedding[0])

                try:
                    vector_store = FAISS.from_documents(text_chunks, embedding=embeddings)
                except Exception as e:
                    st.error(f"Error creating FAISS index: {e}")
                    vector_store = None

                if vector_store:
                    neo4j_driver = GraphDatabase.driver(os.getenv("NEO4J_URI"), auth=(os.getenv("NEO4J_USERNAME"), os.getenv("NEO4J_PASSWORD")))
                    chain, llm = create_conversational_chain(vector_store)
                    display_chat_history(chain, neo4j_driver)
                    
                    if st.sidebar.button("Summarize Documents"):
                        with st.spinner("Generating summary..."):
                            summary = summarize_documents(llm, text_chunks)
                            st.sidebar.subheader("Summary")
                            st.sidebar.write(summary)
                else:
                    st.error("Failed to create vector store from documents.")
            else:
                st.error("No text chunks available for processing.")
        else:
            st.error("No valid text extracted from the uploaded files.")
    else:
        st.sidebar.info("Upload documents to begin.")

if __name__ == "__main__":
    main()
