import numpy as np
import faiss
from transformers import AutoTokenizer, AutoModelForCausalLM
import streamlit as st
import redis
from neo4j import GraphDatabase
from langchain.chains import ConversationalRetrievalChain
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.vectorstores import FAISS
from langchain.memory import ConversationBufferMemory
from langchain.callbacks.streaming_stdout import StreamingStdOutCallbackHandler
from langchain.document_loaders import PyPDFLoader, TextLoader, Docx2txtLoader
from langchain.text_splitter import CharacterTextSplitter
import os
import json
import tempfile
from dotenv import load_dotenv
from bs4 import BeautifulSoup

from sentence_transformers import SentenceTransformer, util

# Load environment variables
load_dotenv()
groq_api_key = os.getenv("GROQ_API_KEY")

def summarize_with_llm(llm, documents):
    """Summarize the provided documents using the existing LLM."""
    summaries = []
    for doc in documents:
        prompt = f"Please provide a concise summary for the following text:\n\n{doc.page_content}"
        try:
            summary = llm(prompt)
        except Exception as e:
            st.error(f"Error summarizing document: {e}")
            summary = "Error summarizing document."
        summaries.append(summary)
    return summaries

class HTMLLoader:
    def __init__(self, file_path):
        self.file_path = file_path

    def load(self):
        try:
            with open(self.file_path, 'r', encoding='utf-8') as file:
                soup = BeautifulSoup(file, 'html.parser')
                text = soup.get_text(separator='\n')
            return [text]
        except Exception as e:
            st.error(f"Error loading HTML file: {e}")
            return []

def process_reranked_docs(reranked_docs):
    return "\n\n".join([doc.page_content for doc in reranked_docs])

class RedisCache:
    def __init__(self, host='localhost', port=6379, db=0):
        self.client = redis.Redis(host=host, port=port, db=db)

    def set(self, key, value):
        try:
            if isinstance(value, (dict, list)):
                value = json.dumps(value)
            self.client.set(key, value)
        except Exception as e:
            st.error(f"Error setting cache value: {e}")

    def get(self, key):
        try:
            value = self.client.get(key)
            if value is None:
                return None
            return json.loads(value.decode('utf-8'))
        except (TypeError, json.JSONDecodeError) as e:
            st.error(f"Error getting cache value: {e}")
            return None

    def add_interaction(self, interaction):
        interaction_id = interaction.get('query', 'default_id')
        self.set(interaction_id, interaction)

redis_cache = RedisCache()

def initialize_session_state():
    if 'history' not in st.session_state:
        st.session_state['history'] = []

    if 'generated' not in st.session_state:
        st.session_state['generated'] = ["Hello! Ask me anything about 🤗"]

    if 'past' not in st.session_state:
        st.session_state['past'] = ["Hey! 👋"]

def store_documents_in_neo4j(text_chunks, neo4j_driver):
    try:
        with neo4j_driver.session() as session:
            for chunk in text_chunks:
                session.run(
                    "CREATE (d:Document {content: $content})",
                    content=chunk.page_content
                )
    except Exception as e:
        st.error(f"Error storing documents in Neo4j: {e}")

def fetch_and_display_documents(neo4j_driver):
    try:
        with neo4j_driver.session() as session:
            result = session.run("MATCH (d:Document) RETURN d.content AS content")
            documents = [record["content"] for record in result]
            return documents
    except Exception as e:
        st.error(f"Error fetching documents from Neo4j: {e}")
        return []

def enhance_query_with_kg(query, neo4j_driver):
    try:
        context = fetch_and_display_documents(neo4j_driver)
        if context:
            return f"{query} Context: {context.get('description', '')}"
    except Exception as e:
        st.error(f"Error enhancing query with KG: {e}")
    return query

def rerank_documents(query, retrieved_docs):
    model = SentenceTransformer('all-MiniLM-L6-v2')
    document_texts = [doc.page_content for doc in retrieved_docs]
    query_embedding = model.encode(query, convert_to_tensor=True)
    doc_embeddings = model.encode(document_texts, convert_to_tensor=True)
    scores = util.cos_sim(query_embedding, doc_embeddings)[0].cpu().numpy()
    sorted_indices = np.argsort(scores)[::-1]
    return [retrieved_docs[i] for i in sorted_indices]

def create_conversational_chain(vector_store):
    retriever = vector_store.as_retriever(search_kwargs={"k": 2})
    llm = ChatGroq(groq_api_key=groq_api_key, model_name="Llama3-8b-8192")
    memory = ConversationBufferMemory(memory_key="chat_history", return_messages=True)
    return ConversationalRetrievalChain.from_llm(
        llm=llm,
        chain_type='stuff',
        retriever=retriever,
        memory=memory,
        return_source_documents=True,
        output_key='answer'
    )

def conversation_chat(query, chain, history, neo4j_driver=None):
    if neo4j_driver:
        query = enhance_query_with_kg(query, neo4j_driver)
    try:
        result = chain.invoke({"question": query, "chat_history": history})
        answer = result.get('answer', 'No answer found')
        source_documents = result.get('source_documents', [])
        history.append((query, answer))
        if source_documents:
            st.write("Source documents:", source_documents)
        return answer
    except Exception as e:
        st.error(f"Error in conversation chat: {e}")
        return "Error processing query."

def display_chat_history(chain, neo4j_driver=None):
    reply_container = st.container()
    container = st.container()

    with container:
        with st.form(key='my_form', clear_on_submit=True):
            user_input = st.text_input("Question:", placeholder="Ask about your Documents", key='input')
            submit_button = st.form_submit_button(label='Send')

        if submit_button and user_input:
            with st.spinner('Generating response...'):
                cached_response = redis_cache.get(user_input)
                if cached_response:
                    output = cached_response.get('response', 'No cached response')
                else:
                    output = conversation_chat(user_input, chain, st.session_state['history'], neo4j_driver)
                    retrieved_docs = chain.retriever.get_relevant_documents(user_input)
                    reranked_docs = rerank_documents(user_input, retrieved_docs)
                    output = process_reranked_docs(reranked_docs)
                    redis_cache.set(user_input, {"response": output})

                st.session_state['past'].append(user_input)
                st.session_state['generated'].append(output)

                feedback = st.radio(
                    "How would you rate this response?",
                    ("Best", "Good", "Normal", "Worst")
                )
                toxic = st.radio("Is this response toxic?", ("Yes", "No"))

                interaction = {
                    "id": "unique_id",
                    "query": user_input,
                    "response": output,
                    "feedback": feedback,
                    "toxic": toxic == "Yes"
                }
                redis_cache.add_interaction(interaction)

    if st.session_state['generated']:
        with reply_container:
            for i in range(len(st.session_state['generated'])):
                st.write(f"User: {st.session_state['past'][i]}")
                st.write(f"Bot: {st.session_state['generated'][i]}")

    if st.button('Summarize Documents'):
        with st.spinner('Summarizing documents...'):
            if 'text_chunks' in st.session_state:
                summaries = summarize_with_llm(chain.llm, st.session_state['text_chunks'])
                st.session_state['summaries'] = summaries
                st.write("Summaries:")
                for summary in summaries:
                    st.write(summary)
            else:
                st.error("No documents available for summarization.")

def main():
    load_dotenv()
    initialize_session_state()
    st.title("B TO B Contract Agreement Chat Bot ")

    st.sidebar.title("Document Processing")
    uploaded_files = st.sidebar.file_uploader("Upload files", accept_multiple_files=True)

    if uploaded_files:
        text = []
        for file in uploaded_files:
            file_extension = os.path.splitext(file.name)[1]
            with tempfile.NamedTemporaryFile(delete=False) as temp_file:
                try:
                    temp_file.write(file.read())
                    temp_file_path = temp_file.name
                    loader = None
                    if file_extension == ".pdf":
                        loader = PyPDFLoader(temp_file_path)
                    elif file_extension in [".docx", ".doc"]:
                        loader = Docx2txtLoader(temp_file_path)
                    elif file_extension == ".txt":
                        loader = TextLoader(temp_file_path)
                    elif file_extension == ".html":
                        loader = HTMLLoader(temp_file_path)

                    if loader:
                        text.extend(loader.load())
                except Exception as e:
                    st.error(f"Error processing file {file.name}: {e}")
                finally:
                    os.remove(temp_file_path)

        if text:
            text_splitter = CharacterTextSplitter(separator="\n", chunk_size=1000, chunk_overlap=100, length_function=len)
            text_chunks = text_splitter.split_documents(text)

            if text_chunks:
                document_texts = [doc.page_content for doc in text_chunks]
                embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2", model_kwargs={'device': 'cpu'})

                try:
                    vector_store = FAISS.from_documents(text_chunks, embedding=embeddings)
                except Exception as e:
                    st.error(f"Error creating FAISS index: {e}")
                    vector_store = None

                if vector_store:
                    neo4j_driver = GraphDatabase.driver(os.getenv("NEO4J_URI"), auth=(os.getenv("NEO4J_USERNAME"), os.getenv("NEO4J_PASSWORD")))
                    store_documents_in_neo4j(text_chunks, neo4j_driver)
                    chain = create_conversational_chain(vector_store)
                    display_chat_history(chain, neo4j_driver)
                else:
                    st.error("Failed to create vector store.")
            else:
                st.error("No valid text chunks found.")
        else:
            st.error("No text extracted from documents.")

if __name__ == "__main__":
    main()
